#debug
set -x

#Which battery should be tested. Usualy it's BAT0, but hey, not in my computer...
battery="BAT1"

#Where should the log be created?
logfile=~/battery_capacity_log-`date '+%Y.%m.%d-%R'`

#####################################

file=$logfile.txt
picture=$logfile.png

#starting the logfile. Let there be light... a date/time combination
echo `date` >> $file

while [[ 1 -eq 1 ]]; do

capacity=`grep remaining /proc/acpi/battery/BAT1/state | cut -f8 -d" "`
echo $capacity >> $file
sleep 5
done
#again a date
echo `date` >> $file


